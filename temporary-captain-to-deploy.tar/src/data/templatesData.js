const templatesData = [
  {
    name: "Study Leave Proposal",
    lastEditedDate: "July 14, 2023",
    link: "/createdocument/studyleave",
  },
  // {
  //   name: "Staff Evaluation",
  //   lastEditedDate: "July 14, 2023",
  //   link: "/createdocument/evaluationtemplate",
  // },
  {
    name: "Early Closure",
    lastEditedDate: "July 14, 2023",
    link: "/createdocument/earlyclosuretemplate",
  },
  // {
  //   name: "Leave Of Absense",
  //   lastEditedDate: "July 14, 2023",
  //   link: "/createdocument/absenceleave",
  // },
];

export default templatesData;
